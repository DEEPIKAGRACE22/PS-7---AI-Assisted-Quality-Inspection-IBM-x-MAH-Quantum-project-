# Casting Defect Classification

- Dataset: Real-Life Industrial Dataset of Casting Product (Kaggle)
- Task: Binary image classification (`defective` vs `ok`)
- Image size: 224 x 224
- Validation accuracy: 0.9947
- Class order: ['defective', 'ok']

## Files
- `casting_defect_classifier_final.keras`: final trained Keras model
- `casting_defect_classifier.keras`: best checkpoint saved during training
- `evaluation_metrics.json`: validation metrics and classification report
- `training_history.csv`: training and validation history
- `class_names.json`: class order used by the model

Note: Validation results are from this notebook run. Performance may vary with a different split or dataset version. This is a project prototype, not a certified industrial inspection system.
